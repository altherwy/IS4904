# Tutorial solution
- Reformat the last code to organize the widgets *horizontally* (Hint: lookup *Row*)


### Solution:




```dart
import 'package:flutter/material.dart';


void main() {
  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // return a widget
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text(
            'First App',
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.purple],
            ),
          ),
          child: Center(
            child: Row(
              children: const [
                Text(
                  'What is your name?',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                ElevatedButton(
                    onPressed: null,
                    child: Text(
                      'submit',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```


- Reformat the last code to change the background color of the *Scaffold* to **Red**.


Solution:
```dart
.
.
.
// code before
backgroundColor: Colors.red
// code after
.
.
.
```


- Reformat the last code to change the *AppBar* color to **Red**.
```dart
.
.
.
// code before
backgroundColor: Colors.blue
// code after
.
.
.
```
- Reformat the last code to change the start and end colors of the gradient effect (Hint: lookup *begin* and *end* in *LinearGradient*)


Solution:
```dart


.
.
.
// code before
decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.blue, Colors.purple],
            ),
          ),
// code after
.
.
.


```
- Reformat the last code to create a new widget called *MyButton* that replaces the *ElevatedButton* widget in the code. However, it should accept the *text* as a parameter. Then, use the *MyButton* widget to create two buttons: *Submit* and *Cancel*.


Solution:
- Define a new widget called *MyButton*,
```dart
class MyButton extends StatelessWidget {
  const MyButton(this.textValue,{super.key});
  final String textValue;
@override
Widget build(BuildContext context) {
  return  ElevatedButton(
      onPressed: null,
      child: Text(
        textValue,
        style: const TextStyle(
          color: Colors.white,
        ),
      ));
}}
```
- Add the newly created widget (*MyButton*) to *MyApp* widget,
```dart
.
.
.
// code before
Column(
              children: const [
                Text(
                  'What is your name?',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                MyButton('Submit'),
                MyButton('Cancel'),
              ],
            ),
// code after            
.
.
.
```
- In Flutter, it is considered a good practice to split the classes into different **.dart** files. Thus, create a new file called *my_app.dart* and move the *MyApp* class to it. Then, import the *my_app.dart* file into the *main.dart* file and fix any errors.


Solution:
1. Create a new file called *my_app.dart* in *lib* folder and move the *MyApp* class to it.
2. Import *'package:flutter/material.dart'* into the *my_app.dart* file.
3. Import the *'my_app.dart'* file into the *main.dart* file.


- Write the code to generate the following snapshot


![https://github.com/altherwy/IS4904/blob/main/pics/Row%20and%20Column%20widgets.jpg?raw=true](https://github.com/altherwy/IS4904/blob/main/pics/Row%20and%20Column%20widgets.jpg?raw=true)


Solution:
```dart
import 'package:flutter/material.dart';


void main() {
  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('First App'),
        ),
        body: Row(
          children: [
            Column(
                children: [
                  Text('Student ID?'),
                  ElevatedButton(onPressed: null, child: Text('submit'))
                ],
            ),
            Column(
              children: [
                Text('Your age?'),
                ElevatedButton(onPressed: null, child: Text('submit'))
              ],
            ),
            Column(
              children: [
                Text('Your name?'),
                ElevatedButton(onPressed: null, child: Text('submit'))
              ],
            ),
          ],
        ),
      ),
    );
  }
}
```
<!--stackedit_data:
eyJoaXN0b3J5IjpbNDM1MTkzNzI4XX0=
-->