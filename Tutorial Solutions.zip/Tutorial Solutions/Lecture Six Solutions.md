# Tutorial Solution
- Modify the *SecondRoute* widget to display the image of the dice that was rolled in the *main* route. For example, if the main *route* shows a *dic-3* image, the *SecondRoute* widget should display the same image.

### Solution
```dart
// second_route.dart
import 'package:flutter/material.dart';

class SecondRoute extends StatelessWidget {
  const SecondRoute(this.imagePath, {Key? key}) : super(key: key);
  final String imagePath;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueGrey, Colors.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextButton(
                  onPressed: () {},
                  child: Image.asset(imagePath),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Go back to the previous page'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```
```dart
// dice_roller.dart
.
.
.
ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SecondRoute(imagePath)),
            );
          },
          child: const Text('Go to the next page'),
        )
.
.
.
```

- Modify the *SecondRoute* widget to display the number of times the dice was rolled in the *main* route. For example, if the dice was rolled 5 times in the *main* route, the *SecondRoute* widget should display the number 5.

### Solution
```dart
// dice_roller.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'my_button.dart';
import 'second_route.dart';

class DiceRoller extends StatefulWidget {
  const DiceRoller({Key? key}) : super(key: key);

  @override
  State<DiceRoller> createState() => _DiceRollerState();
}

class _DiceRollerState extends State<DiceRoller> {
  var activeDiceImage = 'assets/images/dice-1.png';
  List<int> rollCounter = [0,0,0,0,0,0];
  int rollIndex = 0;

  void rollDice() {
    int rand = Random().nextInt(6)+1;

    setState(() {
      activeDiceImage = 'assets/images/dice-$rand.png';
      rollIndex = rand-1;
      rollCounter[rollIndex] = rollCounter[rollIndex]+1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        MyButton(activeDiceImage),
        const SizedBox(
          height: 10,
        ),
        TextButton(
          onPressed: rollDice,
          style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(
                vertical: 10,
              ),
              foregroundColor: Colors.yellow,
              textStyle: const TextStyle(
                fontSize: 28,
              )),
          child: const Text(
            'Roll the dice',
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SecondRoute(activeDiceImage,rollCounter[rollIndex])),
            );
          },
          child: const Text('Go to the next page'),
        )
      ],
    );
  }
}
```
```dart
// second_route.dart
import 'package:flutter/material.dart';

class SecondRoute extends StatelessWidget {
  const SecondRoute(this.imagePath, this.rollCounter, {Key? key})
      : super(key: key);
  final String imagePath;
  final int rollCounter;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueGrey, Colors.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextButton(
                  onPressed: () {},
                  child: Image.asset(imagePath),
                ),
                const SizedBox(height: 20),
                Text(
                  'This dice was rolled $rollCounter times',
                  style: const TextStyle(
                    color: Colors.yellow,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Go back to the previous page'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```

