# Tutorial solution
- Change the width and height of an image to 200 pixels both.
### Solution:
```dart
Image(
  image: AssetImage('assets/images/some_image.jpg'),
  width: 200,
  height: 200,
),
```

- Create an *OutlinedButton* widget that displays the text *Cancel*.
### Solution:
```dart
OutlinedButton(
  onPressed: null,
  child: Text('Cancel'),
),
```

- Create a function called *cancel* that prints *Cancel button is clicked*, and pass it to the *onPressed* parameter of the *OutlinedButton* widget created in the previous step.
### Solution:
```dart
void cancel() {
  print('Cancel button is clicked');
}
.
. // some code here
.
OutlinedButton(
  onPressed: cancel,
  child: Text('Cancel'),
),
```

- Change the background color of the *OutlinedButton* widget to *Colors.purple*.
### Solution:
```dart
OutlinedButton(
  onPressed: cancel,
  style: OutlinedButton.styleFrom(
    backgroundColor: Colors.purple,
  ),
  child: Text('Cancel'),
),
```

- Add a padding of 60 pixels to the *OutlinedButton* widget at the **top and bottom** only.
### Solution:
```dart
OutlinedButton(
  onPressed: cancel,
  style: OutlinedButton.styleFrom(
    backgroundColor: Colors.purple,
    padding: const EdgeInsets.symmetric(vertical: 60.0),
  ),
  child: Text('Cancel'),
),
```
- Add a padding of 10 pixels to the *OutlinedButton* widget using *SizedBox* widget.
### Solution:
```dart
SizedBox(
  height: 10.0,
),
.
. // some code here
.
```
