# Tutorial Solution
- Create a *StatefulWidget* that displays an image. The image should be centered on the screen. The image should change to another image when the user presses a button. You need to add five different images in the *assets* folder. When the user reaches the last image, the image should change back to the first image.
### Solution
```dart
// main.dart
import 'package:flutter/material.dart';
import 'my_app.dart';
void main() {
  runApp(const MyApp());
}
```
```dart
// my_app.dart
import 'package:flutter/material.dart';
import 'dice_roller.dart';
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    // return a widget
    return MaterialApp(
      home: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blueGrey, Colors.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Center(
            child: DiceRoller(),
          ),
        ),
      ),
    );
  }
}
```
```dart
// dice_roller.dart
import 'package:flutter/material.dart';
import 'my_button.dart';
import 'dart:math';
class DiceRoller extends StatefulWidget {
  const DiceRoller({Key? key}) : super(key: key);
  @override
  State<DiceRoller> createState() => _DiceRollerState();
}
class _DiceRollerState extends State<DiceRoller> {
  var activeDiceImage = 'assets/images/dice-1.png';
  int rand = 1;




  void rollDice() {
    setState(() {
        rand = (rand+1)%6;
        activeDiceImage = 'assets/images/dice-${rand+1}.png';
    });
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        MyButton(activeDiceImage),
        const SizedBox(
          height: 10,
        ),
        TextButton(
          onPressed: rollDice,
          style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(
                vertical: 10,
              ),
              foregroundColor: Colors.yellow,
              textStyle: const TextStyle(
                fontSize: 28,
              )),
          child: const Text(
            'Roll the dice',
          ),
        )
      ],
    );
  }
}
```
```dart
// my_button.dart
import 'package:flutter/material.dart';
class MyButton extends StatelessWidget {
  const MyButton(this.textValue,  {super.key});
  final String textValue;
  @override
  Widget build(BuildContext context) {
    return TextButton(
          onPressed: null,
          child: Image.asset(
            textValue,
            height: 200,
            width: 200,
          ),
        );
  }
}
```


- Reformat the code from the previous exercise to display the images in a random order. In other words, the images should be displayed in a random order every time the user presses the button.


### Solution
Same code as before with the only change in the *rollDice* function,
```dart
void rollDice() {
    int rand = Random().nextInt(6)+1;
    setState(() {
      activeDiceImage = 'assets/images/dice-$rand.png';
    });
  }
```
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTE1MjkzNDk3NTBdfQ==
-->